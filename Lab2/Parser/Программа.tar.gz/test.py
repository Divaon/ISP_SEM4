from dis import dis

import pytest

import Toml
import main
import Json

a=3


class A:
  d = 23.1

  def __init__(self):
    self.a = True
    self.b = 21
    self.c = 'Something'

  def sum(self, a, b):
    a=1
    b=3
    return a + b



def sum(self, a, b):
    a = 1
    b = 3
    return a + b


test_simple_hash = {"key1":[3, [1,2], {"key": {"key": [1,2]}, "key1": 1},1], "key2": 2}




SIMPLE_OBJECTS =A()





def test_simple_object():
    serializer=Json.Json()
    print(test_simple_hash, 'hdfgdgf')
    strdata=serializer.dumps(test_simple_hash)
    print(strdata, 'hj')
    fromstrdata=serializer.loads(strdata)
    print(fromstrdata)
    assert fromstrdata==test_simple_hash


def test_simple_object2():
    serializer=Json.Json()
    strdata=serializer.dumps(SIMPLE_OBJECTS)
    print(strdata, '2')
    fromstrdata=serializer.loads(strdata)
    print(fromstrdata, '3')
    print(fromstrdata.a ,'4')
    print(dir(fromstrdata),'5')
    print(dir(SIMPLE_OBJECTS),'6')
    assert fromstrdata.__dict__==SIMPLE_OBJECTS.__dict__


def test_simple_object3():
    serializer=Json.Json()
    strdata=serializer.dumps(sum)
    print(strdata, '2')
    fromstrdata=serializer.loads(strdata)
    print(fromstrdata, '3')
    print(fromstrdata.a ,'4')
    print(dir(fromstrdata),'5')
    print(dir(SIMPLE_OBJECTS),'6')
    assert fromstrdata.__dict__==sum.__dict__



# import Pickle
#
# def test_simple_objectp():
#     serializer=Pickle.Pickle()
#     print(test_simple_hash, 'hdfgdgf')
#     strdata=serializer.dumps(test_simple_hash)
#     print(strdata, 'hj')
#     fromstrdata=serializer.loads(strdata)
#     print(fromstrdata)
#     assert fromstrdata==test_simple_hash
#
# SIMPLE_OBJECTS =A()
# def test_simple_object2p():
#     serializer=Pickle.Pickle()
#     strdata=serializer.dumps(SIMPLE_OBJECTS)
#     # print(strdata, '2')
#     fromstrdata=serializer.loads(strdata)
#     print(fromstrdata, '3')
#     print(dir(fromstrdata),'5')
#     print(dir(SIMPLE_OBJECTS),'6')
#     assert dir(fromstrdata)==dir(SIMPLE_OBJECTS)
#
# SIMPLE_OBJECTS=sum
# def test_simple_object3p():
#     serializer=Pickle.Pickle()
#     strdata=serializer.dumps(SIMPLE_OBJECTS)
#     # print(strdata, '2')
#     fromstrdata=serializer.loads(strdata)
#     # print(fromstrdata, '3')
#     # print(fromstrdata.a ,'4')
#     print(dir(fromstrdata),'5')
#     print(dir(SIMPLE_OBJECTS),'6')
#     assert dir(fromstrdata)==dir(SIMPLE_OBJECTS)
# #
#
# import Yaml
# #serializer=Toml.Toml()
# serializer=Yaml.Yaml()
#
# def test_simple_objecty():
#     print(test_simple_hash, 'hdfgdgf')
#     strdata=serializer.dumps(test_simple_hash)
#     print(strdata, 'hj')
#     fromstrdata=serializer.loads(strdata)
#     print(fromstrdata)
#     assert fromstrdata==test_simple_hash
#
# SIMPLE_OBJECTS =A()
# def test_simple_object2y():
#     strdata=serializer.dumps(SIMPLE_OBJECTS)
#     # print(strdata, '2')
#     fromstrdata=serializer.loads(strdata)
#     print(fromstrdata, '3')
#     print(dir(fromstrdata),'5')
#     print(dir(SIMPLE_OBJECTS),'6')
#     assert fromstrdata.__dict__==SIMPLE_OBJECTS.__dict__
#
# SIMPLE_OBJECTS1=sum
# def test_simple_object3y():
#     strdata=serializer.dumps(SIMPLE_OBJECTS1)
#     print(strdata, '2')
#     fromstrdata=serializer.loads(strdata)
#     print(fromstrdata, '3')
#     # print(fromstrdata.a ,'4')
#     print(dir(fromstrdata),'5')
#     print(dir(SIMPLE_OBJECTS1),'6')
#     assert dir(fromstrdata)==dir(SIMPLE_OBJECTS1)
