import pytest

import main
import Json


test_simple_hash = {"key1":[3, [1,2], {"key": {"key": [1,2]}, "key1": 1},1], "key2": 2}

class A:

    d=23.1

    def __init__(self):
        self.a=True
        self.b=21
        self.c='Something'

    def sum(self, a, b):
        return a+b

SIMPLE_OBJECTS =A()





def test_simple_object():
    serializer=Json.Json()
    print(test_simple_hash, 'hdfgdgf')
    strdata=serializer.dumps(test_simple_hash)
    print(strdata, 'hj')
    fromstrdata=serializer.loads(strdata)
    print(fromstrdata)
    assert fromstrdata==test_simple_hash

def test_simple_object2():
    serializer=Json.Json()
    strdata=serializer.dumps(SIMPLE_OBJECTS)
    print(strdata, '2')
    fromstrdata=serializer.loads(strdata)
    print(fromstrdata, '3')
    print(fromstrdata.a ,'4')
    print(dir(fromstrdata),'5')
    print(dir(SIMPLE_OBJECTS),'6')
    assert fromstrdata.__dict__==SIMPLE_OBJECTS.__dict__