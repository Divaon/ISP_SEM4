import re
import json_converter
import inspect

from types import FunctionType
import sys
import types

class JsonSerializer:
    _complexconvert=False


    def dumps(self, obj) -> str:
        if self._complexconvert:
            obj=self._fromcomplextosimple(obj)
        ret=''
        if  type(obj) is list:
            ret=ret+'['
            for i in range(0, len(obj)):
                if i!=0:
                    ret=ret+','
                ret=ret+self.dumps(obj[i])
            ret=ret+']'
        elif type(obj) is dict:
            ret=ret+'{'
            for key in obj.keys():
                if list(obj.keys())[0]!=key:
                    ret=ret+', '
                dumpedkey=self.dumps(key)
                if dumpedkey[0]!='"' and dumpedkey[-1]!='"':
                    dumpedkey='"'+dumpedkey+'"'
                ret=ret+dumpedkey
                ret=ret+': '
                ret=ret+self.dumps(obj[key])
            ret=ret+'}'

        elif type(obj) is str:
            ret=ret+f"\"{obj}\""
        elif type(obj) is bool:
            if obj:
                ret=ret+'true'
            else:
                ret = ret + 'false'
        elif (type(obj) is float) or (type(obj) is int):
            ret=ret+str(obj)
        else:
            ret=ret+str(obj)
        return ret

    def loads(self, string):
        # obj=json_converter.convert(string)
        string=string.replace('true','True')
        string=string.replace('false','False')
        return eval(string)

    def _fromcomplextosimple(self, obj):
        return obj


    def _fromsimpletocomplex(self, obj):

        return obj

    def splitsstring(self, predata):
        print(predata)
        spliteobj=[ x for x in re.split(r'{|}', predata) if len(x)]
        for string in spliteobj:
            objdata=[]
            for indata in string.split(','):
                splitedstr = indata.split(':')
                for i in range(len(splitedstr)):
                    if splitedstr[i].strip() and splitedstr[i].strip() not in('[', ']' ):
                        objdata.append( splitedstr[i].strip() )
        return objdata

    def _objectfromstring(self, raw_data):
        result={'result':None}
        obj=convert(raw_data)
        return obj

def convert(lst):
    res_dct = { parse(lst[i], len(lst)): parse(lst[i + 1], i) for i in range(0, len(lst), 2)}
    return res_dct

def parse(string, i):
    digit = re.match(r'\d+(\.)?\d*', string)
    if digit:
        result = int(digit[0]) if string.find('.') == -1 else float(digit[0])
        return result
    elif 'true'==string.lower():
        return True
    elif 'false'==string.lower():
        return False
    else:
        string=string.replace('"',"")
        return string
    # elif re.match(r'true|false', raw_data[i].strip('"')):
    #     raw_data[i].strip('"')
    #     result['result'] = raw_data[i] == 'true'
    #     result['i'] = i + 1